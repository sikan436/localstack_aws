import logging

Logger=logging.getLogger()
Logger.setLevel(logging.INFO)

def handler(event,context):
    logging.info('Hands-on-Cloud')
    return {'message':'Hello User' }